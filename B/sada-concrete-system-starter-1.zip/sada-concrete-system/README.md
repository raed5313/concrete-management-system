# SADA AL-EMAR Concrete Management (starter)

Arabic RTL starter website for ready-mix concrete supply orders and loads.

## Run on GitHub Pages
1. Upload `index.html` to the root of your GitHub repository.
2. In repository Settings → Pages, select Deploy from a branch, branch `main`, folder `/ (root)`.
3. Open the generated Pages URL.

## Current features
- Responsive dark Arabic RTL interface inspired by the supplied screenshot.
- Orders, loads, customers, drivers and mixer/vehicle lists.
- Local browser storage, summary metrics, order and load receipt printing.
- This is a local prototype: data stays in the browser/device and does not sync between users.
- Authentication, roles and a shared Supabase database are not yet connected. Do not use this prototype as a secured production system.
