-- SADA AL-EMAR CONCRETE: قاعدة بيانات تأسيسية
-- نفّذ الملف كاملاً في Supabase > SQL Editor > New query.
-- تنبيه: سياسات RLS هنا تسمح للمستخدم المسجّل بإدارة سجلات التشغيل.
-- قبل الاستخدام الفعلي، شدّد الصلاحيات حسب الأدوار المطلوبة.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  role text not null default 'operator' check (role in ('admin','accountant','operator')),
  created_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  address text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_no text not null unique,
  customer_name text not null,
  pour_site text not null,
  concrete_type text not null,
  quantity_m3 numeric(12,2) not null check (quantity_m3 >= 0),
  unit_price numeric(14,2) default 0 check (unit_price >= 0),
  order_date date not null default current_date,
  status text not null default 'new' check (status in ('new','in_progress','completed','cancelled')),
  created_at timestamptz not null default now()
);

create table if not exists public.loads (
  id uuid primary key default gen_random_uuid(),
  order_no text not null,
  load_no integer not null check (load_no > 0),
  customer_name text not null,
  driver_name text not null,
  vehicle_no text not null,
  quantity_m3 numeric(12,2) not null check (quantity_m3 >= 0),
  delivery_date date not null default current_date,
  created_at timestamptz not null default now(),
  unique(order_no, load_no)
);

create table if not exists public.drivers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  license_no text,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.vehicles (
  id uuid primary key default gen_random_uuid(),
  vehicle_no text not null unique,
  vehicle_type text not null,
  capacity_m3 numeric(8,2) default 0 check (capacity_m3 >= 0),
  driver_name text,
  status text not null default 'available',
  created_at timestamptz not null default now()
);

create table if not exists public.inventory_items (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  unit text not null,
  quantity numeric(14,3) not null default 0 check (quantity >= 0),
  minimum_quantity numeric(14,3) not null default 0 check (minimum_quantity >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  transaction_type text not null check (transaction_type in ('قبض','صرف','receipt','expense')),
  description text not null,
  amount_iqd numeric(16,2) not null check (amount_iqd >= 0),
  transaction_date date not null default current_date,
  customer_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.employees (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  job_title text not null,
  phone text,
  salary_iqd numeric(16,2) default 0 check (salary_iqd >= 0),
  created_at timestamptz not null default now()
);

-- Enable Row Level Security on every table.
alter table public.profiles enable row level security;
alter table public.customers enable row level security;
alter table public.orders enable row level security;
alter table public.loads enable row level security;
alter table public.drivers enable row level security;
alter table public.vehicles enable row level security;
alter table public.inventory_items enable row level security;
alter table public.transactions enable row level security;
alter table public.employees enable row level security;

-- A user can read their own profile. Profile writes should be performed by a trusted admin workflow.
drop policy if exists "profile_read_own" on public.profiles;
create policy "profile_read_own" on public.profiles for select to authenticated using (id = auth.uid());

-- Base policies: any authenticated user can manage operational tables.
-- Replace with role-specific policies before production deployment.
do $$
declare t text;
begin
  foreach t in array array['customers','orders','loads','drivers','vehicles','inventory_items','transactions','employees']
  loop
    execute format('drop policy if exists "authenticated_read_%s" on public.%I', t, t);
    execute format('create policy "authenticated_read_%s" on public.%I for select to authenticated using (true)', t, t);
    execute format('drop policy if exists "authenticated_insert_%s" on public.%I', t, t);
    execute format('create policy "authenticated_insert_%s" on public.%I for insert to authenticated with check (true)', t, t);
    execute format('drop policy if exists "authenticated_update_%s" on public.%I', t, t);
    execute format('create policy "authenticated_update_%s" on public.%I for update to authenticated using (true) with check (true)', t, t);
    execute format('drop policy if exists "authenticated_delete_%s" on public.%I', t, t);
    execute format('create policy "authenticated_delete_%s" on public.%I for delete to authenticated using (true)', t, t);
  end loop;
end $$;

-- Helper: create a profile row for each new Auth user, defaulting to operator.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), 'operator')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();
